const o="/xyhelper/logo.png";export{o as _};
